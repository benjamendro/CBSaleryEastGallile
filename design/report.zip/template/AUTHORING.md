# מדריך עריכה · Report Template Authoring Guide
### מרכז הידע האזורי גליל מזרחי — Interactive StoryReport

This is a **reusable, brand-driven report template**. There are two ways to author a
report. **Most people should use Method A — plain Markdown, no code.**

---

## ✦ Method A — write your text in Markdown (no code)

1. Open **`template/content.md`** — it's the whole report as fill-in-the-blanks Markdown
   (headings, fields, and simple tables for chart numbers). It comes pre-filled with the
   current report as a worked example.
2. Edit the text after each `:` and the numbers in the tables. Don't rename the field
   keys (`kicker`, `title`, …) or the `[kind]` tags.
3. **Apply it** — hand the file to your assistant/agent and say *"apply content.md"*.
   It regenerates `template/content.js`, and the report updates. (This is the
   agent-skill workflow: the agent reads `content.md` + this guide and rebuilds the report.)

That's it — you never touch HTML, CSS, or JavaScript.

---

## ✦ Method B — edit the config directly

Edit **`template/content.js`** (the `window.REPORT` object). Same content, expressed as
structured data. Use this when you want full control. Schema below.

---

## עברית — איך עורכים דוח חדש

**הדרך הקלה (ללא קוד):** פתחו את `template/content.md`, מלאו את הטקסט אחרי הנקודתיים
ואת המספרים בטבלאות, ואז בקשו מהסוכן *"apply content.md"* — הדוח ייבנה מחדש.
**להחלפת לוגו:** החליפו את `assets/logo.jpg`. **לעיצוב:** לוח ה-Tweaks (ערכת נושא, צבע, צפיפות).

---

## For an AI agent — how to author a report from this template

You are given this project. Produce a report by **rewriting `window.REPORT` in
`template/content.js`** to match the user's content. Rules:

- Keep the **schema** below. Do not edit `brand.css`, `charts.js`, `render.js`, or the HTML.
- Hebrew RTL is the default. Write copy in the user's language.
- Use **real figures** the user supplies. If a number is missing, leave a clearly-marked
  placeholder and tell the user.
- Pick the right `kind` per section (see catalogue). Order sections to tell a story:
  intro → KPIs → findings (charts) → recommendations → methodology → sources.
- Keep it tight. Every section must earn its place — no filler.

### `REPORT` top-level keys
| key | purpose |
|---|---|
| `brand` | `{ logo, name, nameEn }` — logo + names shown in the top bar |
| `theme` | default look: `"mosaic"` \| `"academic"` \| `"civic"` |
| `nav`   | `[{ id, label }]` — top-bar links; each `id` must match a section `id` |
| `hero`  | `{ meta:[…], title, titleAccent, sub, foot:[…] }` |
| `sections` | ordered array of section objects (below) |
| `footer` | `{ sig, meta:[…] }` |

### Section `kind` catalogue
| kind | what it renders | key fields |
|---|---|---|
| `rich` | heading + paragraphs | `kicker, title, lede, body:[html…]` |
| `kpis` | 4 animated stat cards | `items:[{ value, unit, label, note }]` |
| `barColumns` | vertical bar (distribution) | `data:[{label,value}], unit, source, split?` |
| `barRanked` | horizontal ranked bars | `data:[{label,value}], unit, source, split?` |
| `grouped` | 2-series comparison | `series:[{name,color}], data:[{label,values:[a,b]}]` |
| `donut` | ring / share | `data:[{label,value,color?}], unit` |
| `line` | trend over time | `x:[…], values:[…], unit, color` |
| `pull` | giant number + sentence | `big, txt` (use `band:"dark"`) |
| `flow` | methodology steps | `steps:[{n,title,body,tools:[]}]` |
| `sources` | data-source table | `cols:[…], rows:[{nm,scope,period,quality,notes}]` |
| `recs` | recommendation cards | `items:[{tag,title,body}]` |
| `limits` | caveats grid | `items:[{mk,html}]` |
| `event` | event invite + agenda | `date:{d,m,dow}, agenda:[{t,txt}], contact` |

**Shared optional fields on any section:**
- `id` (string, required) — anchor + nav target.
- `band` — `"alt"` (subtle background) or `"dark"` (dark brand band). Omit for default.
- `kicker`, `title`, `sub`, `source` — labels around the content.
- `split` (on chart kinds) — narrative beside the chart:
  `{ title, body, pull?:{ big, txt } }`.

### Chart colors
Series auto-cycle through the brand palette (`--s1…--s7`). To pin a color use
`color:"var(--c-magenta)"` etc. Brand vars: `--c-cyan --c-sky --c-blue --c-bluedeep
--c-navy --c-magenta --c-lime --c-gold`.

### Quality bars on the sources table
`quality:"high"` → גבוהה, `"med"` → בינונית, `"low"` → מוגבלת.

---

## Files
```
Knowledge Center Report.html   ← open this
assets/logo.jpg                ← brand logo
template/
  content.md   ← ✦ EDIT THIS (plain Markdown, no code) — Method A
  content.js   ← OR edit this (structured config) — Method B
  brand.css    ← design system: RTL, 3 themes, components
  charts.js    ← SVG chart engine (RTL-aware)
  render.js    ← builds the report from content.js
  tweaks-panel.jsx / tweaks-app.jsx  ← theme switcher (Tweaks)
```

---

## Markdown convention (for `content.md` → `content.js`)

When an agent applies `content.md`, map it to `window.REPORT` like this:

- `# REPORT` block → `brand` (`logo`,`name`,`nameEn`) + `theme`.
- `# HERO` → `hero` (`meta` split on ` | ` → array; `title`; `accent`→`titleAccent`;
  `sub`; `foot` split on ` | `).
- `# NAV` lines `label -> id` → `nav:[{id,label}]`.
- `## <id> [<kind>] {<band>}` → one section. `{band}` is optional (`alt`/`dark`).
- Inside a section, `key: value` lines → fields; dotted keys (`split.title`,
  `split.pull.big`) → nested objects.
- A Markdown **table** → the section's data array, keyed by the header row:
  - `kpis` → `items` (`value,unit,label,note`)
  - `barRanked`/`barColumns` → `data` (`label,value`)
  - `grouped` → `data` (`label` + one column per series; `series:` line lists
    `name (color)` pairs split on ` | `)
  - `recs` → `items` (`tag,title,body`); `flow` → `steps` (`n,title,body,tools`
    comma-split); `sources` → `rows`; `limits` → `items` (`mk,html`);
    `event` table → `agenda` (`t,text`), with `date: d | month | weekday`.
- `# FOOTER` → `footer` (`sig`, `meta` list).

Preserve `**bold**` as `<strong>…</strong>` when writing into `content.js`.
